<?php 

/**
 * @category   Ogone
 * @package    Ogone_Exception
 * @copyright  Jurgen Van de Moere
 */

class Ogone_Exception extends Exception
{
    
}

?>