What are the Ogone classes for PHP ?
------------------------------------

The PHP classes for working with the Ogone payment system allow you to
easily create Ogone payment forms and handle Ogone responses in an
efficient and flexible way.

Requirements
------------

The classes are only supported on PHP 5 and up.

Installation
------------

Simply include the classes in your code and instantiate them.

Documentation
-------------

There are a few example scripts in the examples folder that 
contain comments as documentation.

The code in the classes is also well documented.
